Created: 2013-03-04

These tests are obtained as result of debugging sk_treap.
