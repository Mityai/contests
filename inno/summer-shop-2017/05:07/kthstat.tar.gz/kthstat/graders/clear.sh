#!/bin/bash

rm *.o
rm *.ppu
rm sol
rm sol.exe

