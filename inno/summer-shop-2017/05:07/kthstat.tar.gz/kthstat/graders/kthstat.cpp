#include "grader.h"

void Start( int _n, mas _a )
{
}

void Add( int i, int x )
{
}

void Del( int i )
{
}

int Get( int L, int R, int x )
{
  return 0;
}
