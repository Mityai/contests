#!/bin/bash

rm tests.comments
rm gen_rand
rm gen_rand_wide_range 
rm gen_rand_only_find
rm gen_rand_add
rm gen_rand_del
rm gen_rand_add
rm sol
rm validate
