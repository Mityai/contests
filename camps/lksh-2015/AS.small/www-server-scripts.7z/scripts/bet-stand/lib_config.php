<?PHP
  $flock = "/tmp/bet_lock.txt";
  $fmemory = "/tmp/bet_memory.txt";
  $fcontest = "/tmp/bet_contestid.txt";
  $fxmluser = "users.xml";
?>