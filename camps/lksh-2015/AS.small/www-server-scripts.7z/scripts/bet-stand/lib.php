<?PHP

include_once("lib_config.php");

function readUsers($users,$user_info) {
  global $un;
  $un = 0;
  $xmlusers=simplexml_load_string(file_get_contents($fxmluser));
  foreach ($xmlusers->users->user as $user=>$udata) {
    $uid = (string)$udata["id"];
    $users[$un++] = $uid;
    $name = $udata["name"];
    if ($name == NULL || (string)$name == "")
      $name = "?";
    $user_info[$uid]["name"] = $name;
    $user_info[$uid]["score"] = "0";
    $user_info[$uid]["solved"] = "0";
  }
}

function problemID( $contestID, $pid ) {
  return (string)((int)$contestID * 100 + (int)$pid);
}

function getXML($id) {
  return sprintf("/home/judges/%06d/var/status/dir/external.xml",$id);
}

function get_contestid() {
  global $fcontest;
  $f=fopen($fcontest, 'rt');
  if ( $f == false )
    die( "lib.php : failed to open ".$fcontest );
  if (fscanf($f, "%d", $contestid) != 1)
    die ( "lib.php : failed to read ".$fcontest );
  fclose($f);
  return $contestid;
}

function get_lock() {
  global $flock;
  $f=fopen($flock, 'rt');
  if ( $f == false )
    return "unknown";
  $word = fgets($f);
  fclose($f);
  return $word;
}

function check_lock() {
  if (get_lock() != "free")
    die( "LOCKED =(" );
}

function problem_name($s) {
  return strlen($s) <= 5 ? $s : substr($s,0,3)."~".substr($s,-1);
}

?>
