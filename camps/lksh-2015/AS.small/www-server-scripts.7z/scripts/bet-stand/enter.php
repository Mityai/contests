<html>

<head>
<title>Admin room</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="index.css"/>
</head>

<body>

<form action="admin.php?l=<?PHP print($_GET["l"]);?>&r=<?PHP print($_GET["r"]);?>" method="post">

<!--
The first contest <input type="text" id="l" name="l" width=50 value="<?PHP print($_GET["l"]);?>"><br>
The last contest <input type="text" id="r" name="r" width=50 value="<?PHP print($_GET["r"]);?>"><br>
-->

Password <input type="password" id="password" name="password" width=50><br>

<input type="submit" value="Enter">

</form>

</body>
</html>
