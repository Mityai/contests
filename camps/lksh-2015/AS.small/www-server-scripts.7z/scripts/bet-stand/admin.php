<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language" content="ru-ru" />
<link rel="stylesheet" href="index.css"/>
<link rel="stylesheet" href="stand.css"/>
</head>

<body>

<H1>Hiya!</H1>

<?PHP

include_once("lib.php");

if ( $_POST["password"] != "cgfnm" ) die( "ah, you're wrong, man" );

$n=0;
$contestL=$_GET["l"];
$contestR=$_GET["r"];
if ( !isset($contestL) || !isset($contestR) ) {
  die("l & r are not recognized");
}
print("l = ".$contestL.", r = ".$contestR."<br>");

?>

<hr>
<form action="lock.php" method="post">
<h2> Change the bet locking status </h2>
State = <?PHP print(get_lock()); ?><br>
<input type="radio" name="value" value="lock">Lock<br>
<input type="radio" name="value" value="free">Unlock<br>
<input type="submit" value="Change">

</form>

<hr>

<form action="set_contestid.php" method="post">
<span style="font-size: 20; font-weight: bold"> Change the contest ID</span><br>
<input type="text" name="contestid" width=50>
<input type="submit" value="Set"><br>
<?PHP
print("Contest ID = ".get_contestid()."<br>\n");
?>
</form>

<hr>

<?PHP

$xmlfile=sprintf("/var/lib/ejudge/%06d/var/status/dir/external.xml",$contestL);
if (file_exists($xmlfile))  {
  $xmldata=simplexml_load_string(file_get_contents($xmlfile));
} else {
  die(sprintf("Contest is WRONG (%d)", $contestL));
}

$pn = 0;

$un = 0;
$xmlusers=simplexml_load_string(file_get_contents($fxmluser));
foreach ($xmlusers->users->user as $user=>$udata) {
  $uid = (string)$udata["id"];
  $users[$un++] = $uid;
  $name = $udata["name"];
  if ($name == NULL || (string)$name == "")
    $name = "?";
  $user_info[$uid]["name"] = $name;
  $user_info[$uid]["score"] = "0";
  $user_info[$uid]["solved"] = "0";
}

for ($contest = $contestL; $contest <= $contestR; $contest++) {
  $xmlfile2=sprintf("/var/lib/ejudge/%06d/var/status/dir/external.xml",$contest);
  if (file_exists($xmlfile2))  {
    $xmldata2=simplexml_load_string(file_get_contents($xmlfile2));
  } else {
    printf("Contest is INACTIVE (%d)<br>\n", $contest);
    continue;
  }
  foreach ($xmldata2->problems->problem as $prob=>$pdata) {
    $pid0 = $pdata["id"];
    $pid = problemID($contest, $pid0);
    $contest2problem[$contest] = $pid;
    $problems[$pn++] = $pid;
    $problem[$pid] = $pdata;
  }
}

$fw=fopen($fmemory, 'rt');
if ($fw == null) 
  die("admin.php : can not read ".$fmemory);
while (fscanf($fw, "%d%d%d", $ContID, $UserID, $TimeBet) == 3) {
  //print($ContID." ".$UserID." ".$TimeBet."<br>");
  $bet[$contest2problem[(string)$ContID]][(string)$UserID] = (int)$TimeBet;
  //echo $contest2problem[(string)$ContID]." ".$user_info[(string)$UserID]["name"]." ".$TimeBet."<br>";
}
fclose($fw);

include_once("draw_table.php");
?>

</body>
</html>
