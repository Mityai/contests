<?PHP

include_once("lib_config.php");

$word = (string)$_POST['value'];

if ( $word != "free" && $word != "lock" )
  die("lock.php says a-a-a");
$fw = fopen($flock, 'wt');
if ($fw == false)
  die("lock.php can not write file");
fprintf($fw, $word);
fclose($fw);
chmod($flock, 0660);

print('Lock = '.$word);

?>

<script language="JavaScript">
alert( "ok!" );
history.go( -1 );
</script>
