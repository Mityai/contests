<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="ru-ru" />
<link rel="stylesheet" href="index.css"/>
<link rel="stylesheet" href="stand.css"/>
</head>

<body>
<a href="../index.html">Домой</a><br>
<br>

<?PHP
include_once("lib.php");

if (!isset($_GET["l"]) || !isset($_GET["r"])) {
  die("Wrong parameters ('l', 'r')");
}

$n=0;
$contestL=(int)$_GET['l'];
$contestR=(int)$_GET['r'];

$xmlfile=sprintf(getXML($contestL));
if (file_exists($xmlfile))  {
  $xmldata=simplexml_load_string(file_get_contents($xmlfile));
} else {
  die(sprintf("Contest is WRONG (%d)", $contestL));
}

function seconds($t1){
  preg_match('/(\d+)\/(\d+)\/(\d+) (\d+):(\d+):(\d+)/', $t1, $match);
  $cur_time=(int)($match[4])*3600 + (int)($match[5])*60 + (int)($match[6]);
  return $cur_time;
}

$t1=$xmldata["start_time"];
$t2=$xmldata["current_time"];

print('Start = '.$t1.'<br>');
print('Current = '.$t2.'<br>');

$dt = seconds($t2) - seconds($t1);
print('<b>Time passed: '.sprintf("%02dm:%02ds (%02ds)", ($dt / 60), $dt % 60, $dt).'</b><br>');

$pn = 0;
$un = 0;

$xmlusers=simplexml_load_string(file_get_contents($fxmluser));

foreach ($xmlusers->users->user as $user=>$udata) {
  $uid = (string)$udata["id"];
  $users[$un++] = $uid;
  $name = $udata["name"];
  if ($name == NULL || (string)$name == "")
    $name = "?";
  $user_info[$uid]["name"] = $name;
  $user_info[$uid]["score"] = "0";
  $user_info[$uid]["solved"] = "0";
}

for ($contest = $contestL; $contest <= $contestR; $contest++) {
  $xmlfile2=sprintf(getXML($contest));
  if (file_exists($xmlfile2)) {
    $xmldata2=simplexml_load_string(file_get_contents($xmlfile2));
    foreach ($xmldata2->problems->problem as $prob=>$pdata) {
      $contest2problem[$contest] = problemID($contest, $pdata["id"]);
    }
  }
}

$fw=fopen($fmemory, 'rt');
while (fscanf($fw, "%d%d%d", $ContID, $UserID, $TimeBet) == 3) {
  $bet[$contest2problem[(string)$ContID]][(string)$UserID] = (int)$TimeBet;
//  print("betTime=".(int)$TimeBet.";");
//  echo "contest=".$ContID." pid=".$contest2problem[(string)$ContID]." uid=".$UserID." ".$TimeBet."<br>";
}

fclose($fw);

function notNull($x) {
  if ($x == NULL)
    return -1;
  return (int)$x;
}

function getBet( $pid, $uid ) {
  global $bet;
  return notNull($bet[$pid][$uid]);
}

function getTime( $pid, $uid ) {
  global $real_time;
  return notNull($real_time[$pid][$uid]);
}

print("Read contests: ");
for ($contest = $contestL; $contest <= $contestR; $contest++) {
  print("[". $contest.":");
  $xmlfile2=sprintf(getXML($contest));
  if (file_exists($xmlfile2))  {
    printf("OK]");
    $xmldata2=simplexml_load_string(file_get_contents($xmlfile2));
  } else {
    printf("INACTIVE]");
    continue;
  }
  foreach ($xmldata2->problems->problem as $prob=>$pdata) {
    $pid0 = $pdata["id"];
    $pid = problemID($contest, $pid0);
    $contest2problem[$contest] = $pid;
    $problems[$pn++] = $pid;
    $problem[$pid] = $pdata;
  }
  foreach ($xmldata2->runs->run as $run) {
    $pid0 = (string)$run["prob_id"];
    $pid = problemID($contest, $pid0);
    $uid = (string)$run["user_id"];
    $result = (string)$run["status"];
    if ($result == "OK" && $times[$pid][$uid] == NULL) {
      $uBet = getBet($pid, $uid);
      $time = (int)$run["time"];
      $times[$pid][$uid] = max($uBet, $time);
      $real_time[$pid][$uid] = $time;
      //print("real_time=".$time.";");
    }
  }
}
print("<br><br>");

$scores = array(0=>60, 1=>50, 2=>40, 3=>35);

// sort users
function cmpp($u1,$u2){
  if ($u1 > $u2) return 1;
  if ($u1 < $u2) return -1;
  return 0;
}
foreach ($times as $pid=>$ptimes) {
  uasort($ptimes, cmpp);
  $k = 0;
  foreach ($ptimes as $uid=>$time) {
    if (getBet($pid, $uid) < $time)
      $res = 15;
    else {
      $res = ($scores[$k] == NULL ? 30 : $scores[$k]);
      $k = $k + 1;
    }
    $user_info[$uid]["solved"]++;
    $user_info[$uid]["score"] += $res;
    $score[$pid][$uid] = $res;

//    echo "k=".$k." pid=".$pid." uid=".$uid." score=".$score[$pid][$uid]." time=".$time."<br>\n";
  }
}

/*
print("Problems:<br>\n");
foreach ($problems as $p) {
  print($p." : ".$problem[$p]["short_name"]." and ".$problem[$p]["long_name"]."<br>\n");
}
print("Users:<br>\n");
foreach ($users as $u) {
  print($u." : ".$user_info[$u]["name"]." and ".$user_info[$u]["score"]."<br>\n");
}
*/

// sort users
function cmp($u1,$u2){
  if ($u1["score"] < $u2["score"]) return 1;
  if ($u1["score"] > $u2["score"]) return -1;
  if ($u1["solved"] < $u2["solved"]) return 1;
  if ($u1["solved"] > $u2["solved"]) return -1;
  return 0;
}

uasort($user_info,"cmp");

print('<table class="results" cellpadding="3" cellspacing="0" border="1">');
  print('<tr>');
  print('<td>Bets:</td><td>score</td><td>=</td>');
  foreach ($problem as $pid=>$p) {
    print('<td class="problem" title="'.$p["short_name"].': '.$p["long_name"].'">'.problem_name($p["short_name"]).'</td>');
  }
  print("</tr>\n");
  foreach ($user_info as $uid=>$u) {
    print('<tr>');
    print('<td>'.$u["name"].'</td><td>'.$u["score"].'</td><td>'.$u["solved"].'</td>');
    foreach ($problem as $pid=>$p) {
      $text=".";
      $back="white";
      $res = $score[$pid][$uid];
      if ($res != NULL) {
        $back="lightgreen";
        $text="<b>".$res."</b><br>".getTime($pid, $uid)."/".getBet($pid, $uid);
        if (getBet($pid, $uid) < getTime($pid, $uid))
          $back="pink";
      }
      print('<td class="problem" style="background: '.$back.'" title="'.$p["short_name"].': '.$p["long_name"].'">'.$text.'</td>');
    }
    print("</tr>\n");
  }
print("</table>");
?>
