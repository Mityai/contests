<?PHP
$title="ЛКШ.2015.Июль (stand_config)";

function contest_name($s){
  if (strlen($s)>6) return "...".substr($s,-2);
  else return $s;
}

function problem_name($s){
  if (strlen($s)>5) return substr($s,0,3)."~".substr($s,-1);
  else return $s;
}

?>
