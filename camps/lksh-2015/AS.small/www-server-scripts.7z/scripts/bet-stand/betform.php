<html>

<head>
<title>Делаем ставки, Господа! =)</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="index.css"/>
</head>

<body>

<?PHP

include_once("lib.php");

$contest=get_contestid();

print("CONTEST_ID: ".$contest."<br>\n");
if ( isset($_GET["secretid"]) && isset($_GET["time"]) ) {
  $secretid=(int)$_GET['secretid'];
  $time=(int)$_GET['time'];

  if (get_lock() != "free") {
    die( "LOCKED =(" );
  }

  $f=fopen('users.txt', 'rt');
  if ( $f == FALSE ) die( "failed to open users.txt" );
  $ok = 0;
  while (fscanf($f, "%d%d%s", $secret_uid, $real_id, $name) == 3) {
    if ( $secret_uid == $secretid ) {
      printf("<b>Your bet \"contest = ".$contest." user=".$real_id.":".$name." time=".$time."\" has been accepted.</b><br><hr>");

      $fw=fopen($fmemory, 'a+');
      if ($fw == false) 
        die ("betform.php : can not write file ".$fmemory);
      fprintf($fw, $contest." ".$real_id." ".$time."\n");
      fclose($fw);
      chmod($fmemory, 0660);

      $ok = 1;
      break;
    }
  }
  fclose( $f );

  if ( $ok == 0 ) printf( "<b>No such user!</b><br><hr>" ); 
}

?>


<form action="betform.php" method="get">

<input type="hidden" id="contest" name="contest" value=<?PHP echo $_GET['contest']; ?> >
Your secret id: <input type="text" id="secretid" name="secretid" width=70><br>
Your time bet: <input type="text" id="timeid" name="time" width=70><br>
<input type="submit" value="Bet!">

</form>

</body>
</html>
