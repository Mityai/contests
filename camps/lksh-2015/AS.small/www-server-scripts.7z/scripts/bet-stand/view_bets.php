<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="ru-ru" />
<link rel="stylesheet" href="index.css"/>
<link rel="stylesheet" href="stand.css"/>
</head>

<body>
<a href="../index.html">Домой</a><br><br>

<?PHP
include_once("lib.php");

if (!isset($_GET["l"]) || !isset($_GET["r"])) {
  die("Wrong parameters ('begin', 'end')");
}

$n=0;
$contestL=(int)$_GET['l'];
$contestR=(int)$_GET['r'];

$xmlfile=getXML($contestL);
if (file_exists($xmlfile))  {
  $xmldata=simplexml_load_string(file_get_contents($xmlfile));
} else {
  die(sprintf("Contest is WRONG (%d)", $contestL));
}
                           	
  $un = 0;
  $xmlusers=simplexml_load_string(file_get_contents($fxmluser));
  foreach ($xmlusers->users->user as $user=>$udata) {
    $uid = (string)$udata["id"];
    $users[$un++] = $uid;
    $name = $udata["name"];
    if ($name == NULL || (string)$name == "")
      $name = "?";
    $user_info[$uid]["name"] = $name;
    $user_info[$uid]["score"] = "0";
    $user_info[$uid]["solved"] = "0";
  }

$pn = 0;

for ($contest = $contestL; $contest <= $contestR; $contest++) {
  echo "Contest = ". $contest."<br>";
  $xmlfile2=getXML($contest);
  if (file_exists($xmlfile2))  {
    $xmldata2=simplexml_load_string(file_get_contents($xmlfile2));
  } else {
    printf("Contest is INACTIVE (%d)<br>\n", $contest);
    continue;
  }
  foreach ($xmldata2->problems->problem as $prob=>$pdata) {
    $pid0 = $pdata["id"];
    $pid = problemID($contest, $pid0);
    $contest2problem[$contest] = $pid;
    $problems[$pn++] = $pid;
    $problem[$pid] = $pdata;
  }
}

$fw=fopen($fmemory, 'rt');
while (fscanf($fw, "%d%d%d", $ContID, $UserID, $TimeBet) == 3) {
  //print($ContID." ".$UserID." ".$TimeBet."<br>");
  $bet[$contest2problem[(string)$ContID]][(string)$UserID] = (int)$TimeBet;
  //print("problem=".$contest2problem[(string)$ContID]." user=".$user_info[(string)$UserID]["name"]." time=".$TimeBet."<br>");
}
fclose($fw);

include_once("draw_table.php");
?>
