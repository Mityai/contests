<?PHP

include_once("lib_config.php");

$word = (string)$_POST['contestid'];

print('open '.$fcontest.'<br>');
$fw = fopen($fcontest, 'wt');
if ($fw == false)
  die("set_contestid.php : can not write file ".$fcontest);
fprintf($fw, $word);
fclose($fw);
chmod($fcontest, 0660);

print('New Contest ID = '.$word);

?>

<script language="JavaScript">
alert( "ok!" );
history.go( -1 );
</script>
