<?PHP
print('<table class="results" cellpadding="3" cellspacing="0" border="1">');
  print('<tr>');
  print('<td>Bets:</td><td>=</td>');
  foreach ($problem as $pid=>$p) {
    print('<td class="problem" title="'.$p["short_name"].': '.$p["long_name"].'">'.problem_name($p["short_name"]).'</td>');
  }
  print("</tr>\n");
  foreach ($user_info as $uid=>$u) {
    $all = 0;
    $cnt = 0;
    foreach ($problem as $pid=>$p) {
      if ($bet[$pid][$uid] != NULL)
        $cnt = $cnt + 1;
      $all = $all + 1;
    }

    $back="white";
    if ($all == $cnt)
      $back="lightgreen";

    print('<tr>');
    print('<td style="background: '.$back.'">'.$u["name"].'</td><td>'.$cnt.'/'.$all.'</td>');
    foreach ($problem as $pid=>$p) {
      $text=".";
      $back="white";
      if ($bet[$pid][$uid] != NULL) {
        $back="lightgreen";
        $text=$bet[$pid][$uid];
      }
      print('<td class="problem" style="background: '.$back.'" title="'.$p["short_name"].': '.$p["long_name"].'">'.$text.'</td>');
    }
    print("</tr>\n");
  }
print("</table>");
?>
