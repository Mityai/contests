<?PHP

function readQuestions($filename,&$q,&$qn) {
  $f=fopen($filename, 'r');
  if (substr($filename, -4) != ".txt" || strpos($filename, "/") != false) {
    die("try to hack the system");
  }
  if ($f == FALSE) {
    die("can not open file with questions");
  }
  while (($buf = fgets($f)) != false) {
    if (strlen($buf) > 2) {
      $q[$qn] = $buf;
      if ($q[$qn][0] == '$') {
        global $title;
        $title = substr($q[$qn], 1);
      } else {
        $qn += 1;
      }
    }
  }
  fclose($f);
}

$qfile=$_GET["q"];
if ( isset($qfile) ) {
  $qn = 0;
  readQuestions($qfile,$q,$qn);
} else {
  die("usage: *.php?q=file_with_questions");
}

$afile='/tmp/'.$qfile.'.csv';

if ($title == "") {
  $title = "Aнкета [".$qfile."]";
}
?>

<head>
<?PHP
print("<title>".$title."</title>");
?>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <link rel="stylesheet" href="anketa.css"/>
</head>
<body>
<?PHP
print("<h1>".$title."</h1>");

if ( isset($_POST["secretname"]) ) {
  $name=$_POST['secretname'];

  print("Your name = ".$name."<br>\n");
  $f=fopen($afile, 'a+');
  if ($f == FALSE) {
    die("can not open file with answers\n");
  }
  fprintf($f, "%s", $name);
  for ($i = 0; $i < $qn; $i++) {
    if ($q[$i][0] != '#') {
      fprintf($f, ";");
      if (isset($_POST['group'.$i])) {
        fprintf($f, $_POST['group'.$i]);
      }  else {
        fprintf($f, "-");
      }
    }
  }
  fprintf($f, "\n");
  fclose($f);
  chmod($afile, 0666);

  print("Your answer is ok!<br>");
  print("file: ".$afile."<br>");
  print('<a href="main.php?q='.$qfile.'&results">results</a><br>');
  exit;
}

function background($i) {
  if ($i % 2 == 1)
    return "#DDFFDD";
  else
    return "#DDDDFF";
}

if ( isset($_GET["results"]) ) {
  print("<table border=1 cellspacing=0 cellpadding=3>");
  $num = 0;
  for ($i = 0; $i < $qn; $i++) {
    print('  <tr>');
    if ($q[$i][0] == '#') {
      print('<td colspan=2 width=* align=center style="background: #DDDDDD;"><span style="color: blue; font-weight: bold;">'.substr($q[$i], 3).'</span></td>');
    } else {
      $num++;
      print('<td>'.$num.'</td><td>'.$q[$i].'</td>');
    }
    print("</td></tr>\n");
  }
  print("</table>");

  $f=fopen($afile, 'r');
  if ($f == FALSE) {
    die("can not open file with answers\n");
  }
  print("<h1>Ответы</h1>");
  print("<table border=1 cellspacing=0 cellpadding=3>");
  print("<tr>");
  $ans=explode(";", $buf);
  for ($i = 0; $i <= $num; $i += 1) {
    print("<td style='background:".background($i).";'>");
    if ($i == 0)
      print("Name");
    else 
      print($i);
    print("</td>");
  }
  print("</tr>");
  while (($buf = fgets($f)) != false) {
    print("<tr>");
    $ans=explode(";", $buf);
    for ($i = 0; $i <= $num; $i += 1) {
      print("<td style='background:".background($i).";'>");
      print($ans[$i]);
      $sum[$i] += (int)$ans[$i];
      print("</td>");
    }
    print("</tr>");
  }
  print("<tr>");
  for ($i = 0; $i <= $num; $i += 1) {
    print("<td style='background:".background($i).";'>");
    if ($i == 0)
      print("&Sum;");
    else 
      print($sum[$i]);
    print("</td>");
  }
  print("</tr>");
  print("</table>");
  fclose($f);
  exit;
  }
?>

<form action="main.php?<?PHP print('q='.$qfile); ?>" method="post">

<table border=1 cellspacing=0 cellpadding=3>
  <tr><td></td><td><b>Your name:</b></td><td><input type="text" name="secretname" width=70></td></tr>

<?PHP
$num = 0;
for ($i = 0; $i < $qn; $i++) {
  print('  <tr>');
  if ($q[$i][0] == '#') {
    global $cnt;
    $tmp = explode(' ', $q[$i]);
    $cnt = (int)$tmp[1];
    print('<td colspan="3" width=* align=center style="background: #DDDDDD;"><span style="color: blue; font-weight: bold;">'.substr($q[$i], 3).'</span></td>');
  } else {
    $num++;
    print('<td>'.$num.'</td><td>'.$q[$i].'</td><td><p>');
    for ($j = 0; $j < $cnt; $j++) {
      print('<input type="radio" name="group'.$i.'" value="'.$j.'" width=10>'.$j);
    }
  }
  print("</td></tr>\n");
}
?>
</table>
<br>
<input type="submit" value="Finish him!">

</form>

</body>
