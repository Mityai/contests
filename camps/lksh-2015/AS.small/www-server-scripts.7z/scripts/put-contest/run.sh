list=dp.txt
name=023107
f23=out.23
penalty=20

function firstWord {
  awk '{print $1;}'
}

function readList {
  n=0
  while read line ; do
    path=`echo "$line" | firstWord`
    alpha=`echo "print(chr(65 + $n))" | python`
    n=$(($n+1))
    name=${path#*/}
    x=`head -n $n $f23 | tail -n 1 | firstWord`
    #echo $n, $alpha, $path, $name, $x
    sed -e "s/<id_numeric>/$n/g;s/<name>/$name/g;s/<id_alpha>/$alpha/g;s/<x>/$x/g;s/<penalty>/$penalty/g;" template/problem.cfg
  done
}

sed -e "s/<name>/$name/g" template/serve.cfg > serve.cfg
cat $list | sed -e "s/\\\\/\//g" | readList >> serve.cfg
